document.addEventListener("DOMContentLoaded", function () {
    const videoGallery = document.querySelector(".video-gallery");
    const prevButton = document.querySelector(".prev-button");
    const nextButton = document.querySelector(".next-button");
    const videos = videoGallery.querySelectorAll("iframe");
    let currentIndex = 0;
  
    // Función para mostrar el video actual
    function showCurrentVideo() {
      videos.forEach((video, index) => {
        if (index === currentIndex) {
          video.style.display = "block";
        } else {
          video.style.display = "none";
        }
      });
    }
  
    // Función para avanzar al siguiente video
    function nextVideo() {
      currentIndex = (currentIndex + 1) % videos.length;
      showCurrentVideo();
    }
  
    // Función para retroceder al video anterior
    function prevVideo() {
      currentIndex = (currentIndex - 1 + videos.length) % videos.length;
      showCurrentVideo();
    }
  
    // Asigna los manejadores de eventos a los botones de navegación
    prevButton.addEventListener("click", prevVideo);
    nextButton.addEventListener("click", nextVideo);
  
    // Muestra el primer video al cargar la página
    showCurrentVideo();
  });  