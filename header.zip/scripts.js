// Obtener el enlace del carrito y el elemento donde se mostrará la cantidad
const cartLink = document.getElementById("cart-link");
const cartCount = document.createElement("span");
cartCount.classList.add("cart-count");
cartLink.appendChild(cartCount);

// Función para actualizar la cantidad en el carrito
function updateCartCount(count) {
    cartCount.textContent = count;
}

// Ejemplo: Simular una actualización del carrito al hacer clic en "Agregar al carrito"
let cartItemCount = 0;
const addToCartButton = document.getElementById("add-to-cart-button");
addToCartButton.addEventListener("click", function () {
    cartItemCount++;
    updateCartCount(cartItemCount);
});